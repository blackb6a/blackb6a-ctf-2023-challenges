package com.google.android.gms.internal.common;

/* compiled from: com.google.android.gms:play-services-basement@@18.1.0 */
/* loaded from: classes.dex */
abstract class zzm extends zzk {
    private final String zza = "CharMatcher.none()";

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzm(String str) {
    }

    public final String toString() {
        return this.zza;
    }
}