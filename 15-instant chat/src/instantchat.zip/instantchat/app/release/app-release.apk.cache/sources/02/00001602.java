package com.google.android.gms.measurement.internal;

/* compiled from: com.google.android.gms:play-services-measurement@@21.2.0 */
/* loaded from: classes.dex */
public final class zzki extends zzkg {
    /* JADX INFO: Access modifiers changed from: package-private */
    public zzki(zzkt zzktVar) {
        super(zzktVar);
    }
}