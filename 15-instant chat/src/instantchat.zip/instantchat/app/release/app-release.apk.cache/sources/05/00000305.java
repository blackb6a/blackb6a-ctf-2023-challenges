package com.google.firebase;

/* loaded from: classes.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.google.firebase";
    public static final String VERSION_NAME = "20.2.0";
}