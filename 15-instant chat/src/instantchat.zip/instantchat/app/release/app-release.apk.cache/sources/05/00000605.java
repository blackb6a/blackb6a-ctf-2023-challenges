package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-sdk-api@@21.2.0 */
/* loaded from: classes.dex */
final class zzbw implements zzbu {
    private zzbw() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public /* synthetic */ zzbw(zzbv zzbvVar) {
    }
}