package com.google.firebase;

/* loaded from: classes.dex */
public final class DataCollectionDefaultChange {
    public final boolean enabled;

    public DataCollectionDefaultChange(boolean z) {
        this.enabled = z;
    }
}