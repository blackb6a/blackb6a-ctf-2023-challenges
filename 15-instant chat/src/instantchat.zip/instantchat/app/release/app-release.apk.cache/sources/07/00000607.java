package com.google.android.gms.internal.common;

/* compiled from: com.google.android.gms:play-services-basement@@18.1.0 */
/* loaded from: classes.dex */
final class zzn extends zzm {
    static final zzn zza = new zzn();

    private zzn() {
        super("CharMatcher.none()");
    }

    @Override // com.google.android.gms.internal.common.zzo
    public final boolean zza(char c) {
        throw null;
    }
}