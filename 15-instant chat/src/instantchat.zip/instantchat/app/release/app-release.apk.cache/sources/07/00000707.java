package com.google.android.gms.internal.p001firebaseauthapi;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzqw  reason: invalid package */
/* loaded from: classes.dex */
public final class zzqw {
    private final zzqv zza;

    private zzqw(zzqv zzqvVar) {
        this.zza = zzqvVar;
    }

    public static zzqw zzb(byte[] bArr, zzca zzcaVar) {
        return new zzqw(zzqv.zzb(bArr));
    }

    public final int zza() {
        return this.zza.zza();
    }
}