package androidx.lifecycle.livedata.core;

/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}