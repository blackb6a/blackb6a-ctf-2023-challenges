package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-impl@@21.2.0 */
/* loaded from: classes.dex */
public interface zzos {
    double zza();

    long zzb();

    long zzc();

    String zzd();

    boolean zze();
}