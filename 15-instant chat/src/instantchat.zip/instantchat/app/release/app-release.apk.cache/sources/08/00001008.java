package com.google.android.gms.internal.p001firebaseauthapi;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzuu  reason: invalid package */
/* loaded from: classes.dex */
final class zzuu implements zzyg {
    final /* synthetic */ zzyg zza;
    final /* synthetic */ zzuv zzb;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzuu(zzuv zzuvVar, zzyg zzygVar) {
        this.zzb = zzuvVar;
        this.zza = zzygVar;
    }

    @Override // com.google.android.gms.internal.p001firebaseauthapi.zzyf
    public final void zza(String str) {
        this.zza.zza(str);
    }

    @Override // com.google.android.gms.internal.p001firebaseauthapi.zzyg
    public final /* bridge */ /* synthetic */ void zzb(Object obj) {
        Void r1 = (Void) obj;
        this.zzb.zza.zzd();
    }
}