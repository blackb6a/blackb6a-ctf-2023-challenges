package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-base@@21.2.0 */
/* loaded from: classes.dex */
interface zzlj {
    zzlm zza();

    boolean zzb();

    int zzc();
}