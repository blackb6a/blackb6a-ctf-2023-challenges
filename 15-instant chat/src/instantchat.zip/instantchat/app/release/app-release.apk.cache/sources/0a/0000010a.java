package androidx.lifecycle.livedata.core.ktx;

/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}