package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-base@@21.2.0 */
/* loaded from: classes.dex */
interface zzlk {
    zzlj zzb(Class cls);

    boolean zzc(Class cls);
}