package com.google.firebase.appcheck.internal;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class DefaultTokenRefresher$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ DefaultTokenRefresher f$0;

    public /* synthetic */ DefaultTokenRefresher$$ExternalSyntheticLambda0(DefaultTokenRefresher defaultTokenRefresher) {
        this.f$0 = defaultTokenRefresher;
    }

    @Override // java.lang.Runnable
    public final void run() {
        DefaultTokenRefresher.$r8$lambda$8NzzaUeqhmbJQECwCmI2UgFTzGk(this.f$0);
    }
}