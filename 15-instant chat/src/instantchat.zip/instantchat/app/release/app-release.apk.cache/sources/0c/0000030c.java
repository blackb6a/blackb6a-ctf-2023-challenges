package com.google.android.play.core.integrity;

import android.content.Intent;

/* compiled from: com.google.android.play:integrity@@1.0.1 */
/* loaded from: classes.dex */
final class zzu {
    static final Intent zza = new Intent("com.google.android.play.core.integrityservice.BIND_INTEGRITY_SERVICE").setPackage("com.android.vending");
}