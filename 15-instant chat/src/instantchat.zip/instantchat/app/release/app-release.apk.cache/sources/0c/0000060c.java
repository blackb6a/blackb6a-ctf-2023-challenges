package com.google.android.gms.internal.measurement;

import java.util.Iterator;

/* compiled from: com.google.android.gms:play-services-measurement-base@@21.2.0 */
/* loaded from: classes.dex */
final class zzmc implements Iterable {
    @Override // java.lang.Iterable
    public final Iterator iterator() {
        Iterator it;
        it = zzmd.zza;
        return it;
    }
}