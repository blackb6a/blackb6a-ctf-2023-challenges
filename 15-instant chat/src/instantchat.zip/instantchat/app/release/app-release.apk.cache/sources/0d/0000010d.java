package androidx.lifecycle.livedata.ktx;

/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}