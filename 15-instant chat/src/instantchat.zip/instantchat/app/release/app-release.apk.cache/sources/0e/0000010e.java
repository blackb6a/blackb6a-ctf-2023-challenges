package androidx.lifecycle.process;

/* loaded from: classes.dex */
public final class R {
    private R() {
    }
}