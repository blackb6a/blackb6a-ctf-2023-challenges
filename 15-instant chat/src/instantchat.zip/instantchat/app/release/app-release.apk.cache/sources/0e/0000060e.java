package com.google.android.gms.internal.measurement;

/* compiled from: com.google.android.gms:play-services-measurement-base@@21.2.0 */
/* loaded from: classes.dex */
public final class zzko extends zzkp {
    public zzko(String str) {
        super("Protocol message tag had invalid wire type.");
    }
}