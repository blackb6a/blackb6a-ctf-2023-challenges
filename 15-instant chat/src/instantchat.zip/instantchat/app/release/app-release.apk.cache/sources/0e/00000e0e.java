package kotlin.io.path;

import kotlin.Metadata;

@Metadata(d1 = {"kotlin/io/path/PathsKt__PathReadWriteKt", "kotlin/io/path/PathsKt__PathUtilsKt"}, k = 4, mv = {1, 6, 0}, xi = 49)
/* loaded from: classes2.dex */
public final class PathsKt extends PathsKt__PathUtilsKt {
    private PathsKt() {
    }
}