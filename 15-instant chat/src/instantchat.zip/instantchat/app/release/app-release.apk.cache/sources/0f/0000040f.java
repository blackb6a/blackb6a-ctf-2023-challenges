package org.intellij.lang.annotations;

/* loaded from: classes2.dex */
public @interface Identifier {
}