package com.google.android.gms.internal.p001firebaseauthapi;

import java.security.GeneralSecurityException;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzdg  reason: invalid package */
/* loaded from: classes.dex */
final class zzdg extends zzgw {
    /* JADX INFO: Access modifiers changed from: package-private */
    public zzdg(Class cls) {
        super(cls);
    }

    @Override // com.google.android.gms.internal.p001firebaseauthapi.zzgw
    public final /* bridge */ /* synthetic */ Object zza(zzaek zzaekVar) throws GeneralSecurityException {
        return new zzqu(((zzpe) zzaekVar).zze().zzt());
    }
}