package kotlinx.coroutines;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class CoroutineId$$ExternalSyntheticBackport0 {
    public static /* synthetic */ int m(long j) {
        return (int) (j ^ (j >>> 32));
    }
}