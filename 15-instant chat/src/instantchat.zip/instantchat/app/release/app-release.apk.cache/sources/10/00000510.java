package com.google.android.gms.internal.p001firebaseauthapi;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzkp  reason: invalid package */
/* loaded from: classes.dex */
final /* synthetic */ class zzkp {
    static final /* synthetic */ int[] zza;

    static {
        zzade.zza();
        int[] iArr = new int[7];
        zza = iArr;
        try {
            iArr[3] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            zza[4] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            zza[2] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            zza[5] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            zza[6] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            zza[0] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            zza[1] = 7;
        } catch (NoSuchFieldError unused7) {
        }
    }
}