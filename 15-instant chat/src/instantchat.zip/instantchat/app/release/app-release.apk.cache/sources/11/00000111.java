package androidx.lifecycle.runtime;

/* loaded from: classes.dex */
public final class R {

    /* loaded from: classes.dex */
    public static final class id {
        public static final int view_tree_lifecycle_owner = 0x7f080203;

        private id() {
        }
    }

    private R() {
    }
}