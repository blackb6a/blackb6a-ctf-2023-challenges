package com.google.android.gms.internal.stats;

import java.io.Closeable;

/* compiled from: com.google.android.gms:play-services-stats@@17.0.1 */
/* loaded from: classes.dex */
public final class zzb implements Closeable {
    private static final zzb zza = new zzb(false, null);

    private zzb(boolean z, zzd zzdVar) {
    }

    public static zzb zza(boolean z, zzc zzcVar) {
        return zza;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }
}