package com.google.android.gms.internal.p001firebaseauthapi;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzaeh  reason: invalid package */
/* loaded from: classes.dex */
interface zzaeh {
    zzaek zza();

    boolean zzb();

    int zzc();
}