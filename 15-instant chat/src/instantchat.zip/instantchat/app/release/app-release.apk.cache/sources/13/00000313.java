package com.google.firebase.components;

/* loaded from: classes.dex */
public class DependencyException extends RuntimeException {
    public DependencyException(String str) {
        super(str);
    }
}