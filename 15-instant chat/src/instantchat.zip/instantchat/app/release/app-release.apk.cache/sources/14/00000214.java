package com.google.android.gms.internal.measurement;

import java.util.List;

/* compiled from: com.google.android.gms:play-services-measurement@@21.2.0 */
/* loaded from: classes.dex */
public interface zzr {
    void zza(int i, String str, List list, boolean z, boolean z2);
}