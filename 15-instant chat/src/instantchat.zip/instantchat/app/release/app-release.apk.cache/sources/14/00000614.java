package com.google.android.gms.internal.p001firebaseauthapi;

import java.util.Iterator;

/* compiled from: com.google.firebase:firebase-auth@@21.1.0 */
/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzafb  reason: invalid package */
/* loaded from: classes.dex */
final class zzafb implements Iterable {
    @Override // java.lang.Iterable
    public final Iterator iterator() {
        Iterator it;
        it = zzafc.zza;
        return it;
    }
}